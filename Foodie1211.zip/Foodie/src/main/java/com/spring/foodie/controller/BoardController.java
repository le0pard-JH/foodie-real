package com.spring.foodie.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class BoardController {
	   
	@RequestMapping(value="/index.food")
	   public ModelAndView MainPage(ModelAndView mav) {
	      
	      mav.setViewName("main/index.tiles1");
	      //      /WEB-INF/views/tiles1/main/index.jsp 왜 안되는거야!!!!!!!!!!!
	      
	      return mav;
	   }   

	
	 	}
