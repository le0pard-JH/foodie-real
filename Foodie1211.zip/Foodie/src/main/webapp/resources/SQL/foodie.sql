show user;

select * from store_raw where addr_new like '%영등포구%' and STORE_NAME like '송죽장';

select * from store_raw

