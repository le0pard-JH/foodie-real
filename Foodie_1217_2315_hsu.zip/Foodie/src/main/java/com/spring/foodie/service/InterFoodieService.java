package com.spring.foodie.service;

import java.util.Map;

import com.spring.foodie.model.MemberVO;

public interface InterFoodieService {
	
	MemberVO emailDuplicateCheck(String email); // 아이디 중복검사하기

	MemberVO getLoginMember(Map<String, String> paraMap); // 로그인 처리하기

	int registerMember(Map<String, String> paraMap);	// 회원가입 처리하기

	//int registerMember(MemberVO member);	// 회원가입 처리하기
	int registerMember(MemberVO member);	// 회원가입 처리하기
	

	void pointPlus(Map<String, String> paraMap);
	
	
}






