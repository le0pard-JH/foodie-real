package com.spring.foodie.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.social.connect.Connection;
import org.springframework.social.google.api.Google;
import org.springframework.social.google.api.impl.GoogleTemplate;
import org.springframework.social.google.api.plus.Person;
import org.springframework.social.google.api.plus.PlusOperations;
import org.springframework.social.google.connect.GoogleConnectionFactory;
import org.springframework.social.oauth2.AccessGrant;
import org.springframework.social.oauth2.GrantType;
import org.springframework.social.oauth2.OAuth2Operations;
import org.springframework.social.oauth2.OAuth2Parameters;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.spring.foodie.model.MemberVO;
import com.spring.foodie.service.FoodieService;
import com.sun.org.apache.xml.internal.utils.URI;

@Component
@Controller
public class LoginController {

	FoodieService service;
	@Autowired
	private GoogleConnectionFactory googleConnectionFactory;

	@Autowired
	private OAuth2Parameters googleOAuth2Parameters;

	// 로그인 페이지로 이동하는 컨트롤러
	@RequestMapping(value = "/login.food")
	public String initLogin(Model model, HttpSession session, HttpServletResponse response) throws Exception {

		/* 구글code 발행 */
		OAuth2Operations oauthOperations = googleConnectionFactory.getOAuthOperations();

		/* 로그인페이지 이동 url생성 */
		String url = oauthOperations.buildAuthorizeUrl(GrantType.AUTHORIZATION_CODE, googleOAuth2Parameters);

		System.out.println("구글: " + url);
		model.addAttribute("google_url", url);
		/*
		 * PrintWriter out; try { out = response.getWriter(); out.write(url);
		 * out.flush(); out.close(); } catch (IOException e) { throw new
		 * RuntimeException(e.getMessage(), e); }
		 */
		/* 생성한 인증 URL을 Model에 담아서 전달 */
		return "login";
	}

	// 구글 Callback호출 메소드
	@RequestMapping(value = "/oauth2callback.food", method = { RequestMethod.GET, RequestMethod.POST })
	public String googleCallback(Model model, @RequestParam String code) throws IOException {
		System.out.println("여기는 googleCallback");
		return "googleSuccess";
	}

	/*
	 * // 구글 Callback호출 메소드
	 * 
	 * @RequestMapping(value = "/oauth2callback.food", method = { RequestMethod.GET,
	 * RequestMethod.POST }) public String googleCallback(Model model, @RequestParam
	 * String code,HttpServletRequest request) throws IOException {
	 * System.out.println("여기는 googleCallback"); code =
	 * request.getParameter("code");
	 * 
	 * OAuth2Operations oauthOperations =
	 * googleConnectionFactory.getOAuthOperations(); AccessGrant accessGrant =
	 * oauthOperations.exchangeForAccess(code ,
	 * googleOAuth2Parameters.getRedirectUri(), null);
	 * 
	 * String accessToken = accessGrant.getAccessToken(); Long expireTime =
	 * accessGrant.getExpireTime(); if (expireTime != null && expireTime <
	 * System.currentTimeMillis()) { accessToken = accessGrant.getRefreshToken();
	 * System.out.printf("accessToken is expired. refresh token = {}", accessToken);
	 * } Connection<Google> connection =
	 * googleConnectionFactory.createConnection(accessGrant); Google google =
	 * connection == null ? new GoogleTemplate(accessToken) : connection.getApi();
	 * 
	 * PlusOperations plusOperations = google.plusOperations(); Person person =
	 * plusOperations.getGoogleProfile();
	 * 
	 * MemberVO member = new MemberVO(); member.setName(person.getDisplayName());
	 * member.setEmail(person.getAccountEmail()); member.setUserid(person.getId());
	 * member.setGender(person.getGender()); member.set
	 * 
	 * HttpSession session = request.getSession(); session.setAttribute("_MEMBER_",
	 * member );
	 * 
	 * System.out.println("Lctrl setname"+person.getDisplayName());
	 * System.out.println("Lctrl setemail"+person.getAccountEmail());
	 * System.out.println("Lctrl setuserid"+person.getDisplayName());
	 * System.out.println("Lctrl setGender"+person.getGender());
	 * 
	 * return "redirect:/"; //System.out.println(person.getAccountEmail());
	 * //System.out.println(person.getAboutMe());
	 * //System.out.println(person.getDisplayName());
	 * //System.out.println(person.getEtag());
	 * //System.out.println(person.getFamilyName());
	 * //System.out.println(person.getGender());
	 * 
	 * return "googleSuccess"; }
	 */
}
