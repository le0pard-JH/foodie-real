package com.spring.foodie.login;

public class GoogleLoginBO {

}
