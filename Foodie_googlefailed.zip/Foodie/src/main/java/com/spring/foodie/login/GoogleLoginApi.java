package com.spring.foodie.login;

import org.springframework.social.*;

public class GoogleLoginApi {
	
	protected GoogleLoginApi() {}
	
	private static class InstanceHolder{
		private static final GoogleLoginApi INSTANCE = new GoogleLoginApi(); 
	}
	
	public static GoogleLoginApi instance() {
		return InstanceHolder.INSTANCE;
	}
//https://accounts.google.com/o/oauth2/v2/auth
//https://accounts.google.com/signin/v2/challenge/pwd?client_id=497432265348-e6ar785a24otkq1us9fplikk92rq71f8.apps.googleusercontent.com
//&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fplus.login&redirect_uri=http%3A%2F%2Flocalhost%3A9090%2Ffoodie%2Foauth2callback.food
//&flowName=GeneralOAuthFlow&cid=1&navigationDirection=forward&TL=AM3QAYZvvjT0VSVZG35IZfh3neY8Po2gpgEfExCIBtL618PFJHk-mzE-ILoxq95Z	
	
//http://localhost:9090/foodie/oauth2callback.food?code=4%2F0AY0e-g6ERqlLtwaLS5LtSZRCfZ4OtMb9FFz62P08Jwss59yS25Zo2nfhZJa2gjCzHFWy5w
//&scope=profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile#
		
	@Override
    public String getAccessTokenEndpoint() {
        return "https://nid.naver.com/oauth2.0/token?grant_type=authorization_code";
    }
	
	@Override
    protected String getAuthorizationBaseUrl() {
        return "https://nid.naver.com/oauth2.0/authorize";
    }

}
