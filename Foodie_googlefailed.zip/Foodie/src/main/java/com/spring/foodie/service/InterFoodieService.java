package com.spring.foodie.service;

public interface InterFoodieService {

	
}






