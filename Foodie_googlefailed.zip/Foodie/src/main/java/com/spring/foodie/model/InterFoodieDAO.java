package com.spring.foodie.model;


public interface InterFoodieDAO {
	
	
}







