package com.spring.foodie.model;

import java.sql.SQLException;
import java.util.Map;

public interface InterFoodieDAO {

	// 회원가입을 해주는 메소드 (tbl_member 테이블에 insert)
	int registerMember(MemberVO member) throws SQLException;
	// String registerMember(MemberVO member) throws SQLException;

	int registerMember(Map<String, String> paraMapmember) throws SQLException;

	MemberVO emailDuplicateCheck(String email); // 이메일중복검사

	MemberVO getLoginMember(Map<String, String> paraMap); // 로그인 멤버가져오기

	void pointPlus(Map<String, String> paraMap);

	int updateIdle(String userid);

}
