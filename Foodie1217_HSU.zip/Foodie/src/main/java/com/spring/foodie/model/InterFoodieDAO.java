package com.spring.foodie.model;

import java.util.Map;

public interface InterFoodieDAO {

	MemberVO emailDuplicateCheck(String email); // 이메일중복검사

	MemberVO getLoginMember(Map<String, String> paraMap); // 로그인 멤버가져오기
	
	
}







