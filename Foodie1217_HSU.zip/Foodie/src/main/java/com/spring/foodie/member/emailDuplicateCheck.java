package com.spring.foodie.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.web.servlet.ModelAndView;

import com.spring.foodie.model.InterMemberDAO;
import com.spring.foodie.model.MemberDAO;

public class emailDuplicateCheck {
	/*
	 * @Override public void execute(ModelAndView mav, HttpServletRequest request,
	 * HttpServletResponse response) {
	 * 
	 * String email = request.getParameter("email");
	 * 
	 * InterMemberDAO mdao = new MemberDAO(); boolean isExists =
	 * mdao.emailDuplicateCheck(email);
	 * 
	 * JSONObject jsonObj = new JSONObject(); // {} jsonObj.put("isExists",
	 * isExists); // {"isExists":true} 또는 {"isExists":false} 으로 만들어준다.
	 * 
	 * String json = jsonObj.toString(); // 문자열 형태인 {"isExists":true} 또는
	 * {"isExists":false} 으로 만들어준다. // System.out.println(">>> 확인용 json => " +
	 * json); // {"isExists":true} {"isExists":false}
	 * 
	 * request.setAttribute("json", json);
	 * 
	 * 
	 * }
	 */

}
