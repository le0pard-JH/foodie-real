package com.spring.foodie.model;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.mybatis.spring.SqlSessionTemplate;

public class MemberDAO implements InterMemberDAO {

	@Resource
	private SqlSessionTemplate sqlsession;
	
	@Override
	public int registerMember(MemberVO member) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public int registerMember(Map<String, String> paraMap) throws SQLException {
		int n = sqlsession.insert("foodie.register_member_map", paraMap);
		return n;
	}

	@Override
	public boolean idDuplicateCheck(String userid) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean emailDuplicateCheck(String email) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public MemberVO selectOneMember(Map<String, String> paraMap) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findUserid(Map<String, String> paraMap) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isUserExist(Map<String, String> paraMap) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int pwdUpdate(Map<String, String> paraMap) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int coinUpdate(Map<String, String> paraMap) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateMember(MemberVO member) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<MemberVO> selectMember(Map<String, String> paraMap) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MemberVO> selectPagingMember(Map<String, String> paraMap) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotalPage(Map<String, String> paraMap) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public MemberVO memberOneDetail(String userid) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
